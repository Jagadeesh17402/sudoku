# Notes for future streams
- re-run all performance tests with a proper callgraph
- re-introduce killer sudoku


## Killer sudoku

- generate map of sums
  - Size of puzzle -> Size of Killer block -> Sum of Killer block -> vector of vector of number
- plug in the killer sudoku solving techniques into the solver
- solving technique that limits the possible numbers and possible sets of numbers across the squares inside of the Killer cage