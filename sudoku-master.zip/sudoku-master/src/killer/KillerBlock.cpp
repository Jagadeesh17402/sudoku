// (c) 2020 RNDr. Simon Toth (happy.cerberus@gmail.com)

#include "KillerBlock.h"
